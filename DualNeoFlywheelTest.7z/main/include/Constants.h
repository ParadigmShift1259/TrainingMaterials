/*----------------------------------------------------------------------------*/
/* Copyright (c) 2019 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#pragma once

#include <units/time.h>
#include <units/velocity.h>
#include <units/acceleration.h>
#include <wpi/numbers>

using namespace units;

namespace OIConstants
{
    constexpr double kDeadzoneX = 0.015;
    constexpr double kDeadzoneY = 0.015;
    constexpr double kDeadzoneXY = 0.08;
    constexpr double kDeadzoneRot = 0.10;
    constexpr double kDeadzoneAbsRot = 0.50;

    constexpr int kPrimaryControllerPort = 0;
}

// Flywheel Subsystem constants
namespace FlywheelConstants
{
    constexpr double kPrimaryMotorPort = 1;     //!< Flywheel CAN ID (Primary SparkMAX)
    constexpr double kFollowerMotorPort = 2;            //!< Flywheel CAN ID (Following SparkMAX)

    constexpr double kRampRate = 1.0;
    // Total error allowed for the flywheel, in RPM
    constexpr double kAllowedError = 75;
    constexpr double kMaintainPIDError = 300;

    // General multiplier added, adjusts for ball conditions and general firing
    constexpr double kHomingRPMMultiplier = 1.0175;
    constexpr double kIdleHomingRPMMultiplier = 1.01;
    // Additional multiplier applied to flywheel speed while firing 
    // Ensures all ball trajectories are straight
    constexpr double kFiringRPMMultiplier = 1.01; //TEMP 1.015; //2; //1.035; //1.05;

    // Launch PID values, used to first get to setpoint
    constexpr double kP = 0.0002900;
    constexpr double kI = 0;
    constexpr double kD = 0;

    // Maintain PID values, used to adjust for error once the robot is shooting
    constexpr double kMP = 0.002000;
    constexpr double kMI = 0.00000001;
    constexpr double kMD = 0.000001;

    constexpr double kMinOut = 0;
    constexpr double kMaxOut = 1.0;

    constexpr double kS = 0.26625;  // Characterization should be repeated with 2 Neos
    constexpr double kV = 0.12771;
    constexpr double kA = 0.031171;

    // Diameter is in meters
    constexpr double kWheelDiameter = 0.1016;   // 4 inches
    constexpr double kSecondsPerMinute = 60;
    constexpr double kWheelMetersPerRev = kWheelDiameter * wpi::numbers::pi;
    // Meters per second to Revolutions per minute
    constexpr double kMPSPerRPM = kWheelMetersPerRev / kSecondsPerMinute;
    constexpr double kWheelRevPerMotorRev = 1.3;

    /// Use MPSPerRPM to determine the ramp rates, current values are just placeholders
    constexpr double kIdleRPM = 2000;
    /// The fixed RPM to fire at the trench given very heavy defense
    constexpr double kTrenchRPM = 3000;
}
