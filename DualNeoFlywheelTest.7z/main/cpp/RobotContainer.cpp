/*----------------------------------------------------------------------------*/
/* Copyright (c) 2019 FIRST. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include "RobotContainer.h"
#include <frc2/command/button/NetworkButton.h>

RobotContainer::RobotContainer()
    : m_flywheel()
{
    ConfigureButtonBindings();
    SetDefaultCommands();

    m_chooser.SetDefaultOption("Example 1", TestOptions::kEx1);
    m_chooser.AddOption("Example 2", TestOptions::kEx2);
    m_chooser.AddOption("Example 3", TestOptions::kEx3);
    m_chooser.AddOption("Example 4", TestOptions::kEx4);
    m_chooser.AddOption("Example 5", TestOptions::kEx5);
    frc::SmartDashboard::PutData("Test Options", &m_chooser);
}

void RobotContainer::Periodic() {
}

void RobotContainer::SetDefaultCommands()
{
    // m_flywheel.SetDefaultCommand(
    //     frc2::RunCommand(
    //         [this] {
    //             m_flywheel.SetRPM(FlywheelConstants::kIdleRPM);
    //         }, {&m_flywheel}
    //     )
    // );
}

void RobotContainer::ConfigureButtonBindings()
{
    frc2::JoystickButton(&m_primaryController, (int)frc::XboxController::Button::kA).WhenPressed(
        frc2::InstantCommand(    
            [this] { 
                m_flywheel.SetRPM(m_flywheel.GetRPM() + 100.0);
             },
            {&m_flywheel}
        )
    );

    frc2::JoystickButton(&m_primaryController, (int)frc::XboxController::Button::kB).WhenPressed(
        frc2::InstantCommand(    
            [this] { 
                m_flywheel.SetRPM(m_flywheel.GetRPM() - 100.0);
             },
            {&m_flywheel}
        )
    );
}

